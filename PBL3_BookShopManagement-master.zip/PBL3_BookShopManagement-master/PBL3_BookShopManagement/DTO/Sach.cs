﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3_BookShopManagement.DTO
{
    class Sach
    {
        public int MaSach { get; set; }
        public string TenSach { get; set; }
        public int GiaMua { get; set; }
        public string TenLoaiSach { get; set; }
        public string TenTacGia { get; set; }
        public string TenLinhVuc { get; set; }
    }
}
